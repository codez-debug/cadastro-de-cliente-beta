package cadastro;

import java.util.ArrayList;
import java.util.List;

public class UsuarioService {
    private List<Usuario> usuarios = new ArrayList<>();

    public void adicionarUsuario(String nome, String email) {
        usuarios.add(new Usuario(nome, email));
    }

    public List<Usuario> listarUsuarios() {
        return usuarios;
    }

    public boolean removerUsuario(String email) {
        return usuarios.removeIf(usuario -> usuario.getEmail().equals(email));
    }
}